#include <stdio.h>

int main(void)
{
	int a, b;

	printf("Input two integers: ");

	scanf_s("%d", &a);
	scanf_s("%d", &b);

	if (a % b == 0) printf("%d is a multiple of %d by a factor of %d \n", a, b, a / b);

	else printf("%d is not a multiple of %d \n", a, b);

	return 0;

}