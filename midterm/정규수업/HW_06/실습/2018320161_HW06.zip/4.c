#include <stdio.h>

int pli(char *str1, char *str2);

int main(void) {

	char string1[80];
	char string2[80];

	printf("Enter one string:");
	gets_s(string1);

	pli(string1, string2);

	return 0;
}

int  pli(char *str1, char *str2) {
	int end = -1,judge=2,i;
	for (i = 0; str1[i]; i++) end++;

	for (i = 0; str1[i]; i++) {
		if (str1[i] != str1[end - i]) {
			judge = 0; break;
		}
		else if (i = end) judge = 1;
	}
	
	if (judge) printf("\'%s\' is a palindrome\n",str1);

	else {
		for (i = 0; str1[i]; i++) str2[i] = str1[i];
		for (i = 0; i <= end; i++) str2[i + end] = str1[end - i];
		str2[2 * end + 1] = NULL;
		printf("We can make a polindrome \'%s\' from \'%s\'\n", str2, str1);
	}

	return 1;
}